
Page({
  data:
  {
    light:0,
    second:0,
    color :"waiting",
    longitude:0,
    latitude:0
  },
  Get_light: function(){
    var dy1=this
    let deviceid = "642900158"
    let apikey = "gDHmVo=2WOQd8kF6MuSSHmvfQls="
    wx.request({
      url: "https://api.heclouds.com/devices/" + deviceid + "/datastreams",
      method:'GET',
      header:{
        "content-type": 'application/x-www-form-urlencoded',
        "api-key": apikey
      },
      success(res){
        dy1.setData({light:res.data.data[0].current_value})
        dy1.setData({second:res.data.data[1].current_value})
        console.log(dy1.data.light)
        console.log(dy1.data.second)
        if(dy1.data.light=1) {
          dy1.setData({color:"红灯"})
        }
        if(dy1.data.light=0){
          dy1.setData({color:"绿灯"})
        }
      },
    })
  },
  Get_GPS:function(){
    var dy2=this
    let deviceid = "655066572"              
    let apikey = "pQR=XNm8dcjqpqPQQ4zALoLNG5U="   
    wx.request({
      url: "https://api.heclouds.com/devices/" + deviceid + "/datastreams",
      method:'GET',
      header:{
        "content-type": 'application/x-www-form-urlencoded',
        "api-key": apikey
      },
      success(res){
        dy2.setData({latitude:res.data.data[0].current_value})
        dy2.setData({longitude:res.data.data[1].current_value})
        console.log(res)  
        console.log(res.data.data[0].current_value)   
        console.log(res.data.data[1].current_value)
        }
})
  }
})
